// require dependincies
var express = require('express');
var router = express.Router();

var multer  = require('multer')
var upload = multer({ dest: 'public/uploads/' })

var session = require('express-session')

var projectController = require('./controllers/projectController');
var userController = require('./controllers/userController');
var portfolioController = require('./controllers/portfolioController');
// add routes

//router.post('/project', projectController.createProject);
router.post('/CreatePortfolio',upload.any(),portfolioController.createPortfolio);
router.get('/loadcreateportfolio',portfolioController.loadCreatePortfolio);
router.get('/',projectController.getAllPorfolios);
router.post('/createAccount',userController.createUser);
router.post('/login',userController.login);
router.post('/ViewProject',projectController.viewsscreenshot);

// export router

module.exports = router;
