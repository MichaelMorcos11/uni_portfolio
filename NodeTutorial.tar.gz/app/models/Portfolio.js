var mongoose = require('mongoose');

var portfolioSchema = mongoose.Schema({
    Email:{
      type:String,
      required:true
    },
    Password:{
      type:String,
      required:true
    },
    projects:[{type:mongoose.Schema.Types.ObjectId,ref:'project'}],
    profilepicture:String
})

var Portfolio = mongoose.model("portfolio", portfolioSchema);

module.exports = Portfolio;
