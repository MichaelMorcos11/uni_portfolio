
let Portfolio = require('../models/Portfolio')

let userController = {
    login:function(req,res){
      Portfolio.findOne({Email:req.body.Email},function(err,user){
        if(req.body.Password==user.Password){
          req.session.user=user;
        
          res.redirect('/loadcreateportfolio');
        }else{

          res.send('failed');
        }
      })
    },
    getAllUsers:function(req, res){

        Portfolio.find(function(err, users){

            if(err)
                res.send(err.message);
            else
                res.render('MyUsers', {users});
        })
    },
    getAllPorfolios:function(req, res){

        Portfolio.find(function(err, portfolio){

            if(err)
                res.send(err.message);
            else
                res.render('AllPortfolios', {portfolio});
        })
    },

    registerAccount:function(req, res){

        Portfolio.find(function(err, users){

            if(err)
                res.send(err.message);
            else
                res.render('Homepage', {users});
        })
    },

    createUser:function(req, res){
        let user = new Portfolio(req.body);

        user.save(function(err, user){
            if(err){
                res.send(err.message)
                console.log(err);
            }
            else{
                console.log(user);
                res.redirect('/');
            }
        })
    }
}

module.exports = userController;
