
let Portfolio = require('../models/Portfolio')

let portfolioController = {
    login:function(req,res){
      Portfolio.findOne({email:req.body.Email},function(err,portfolio){
        if(req.body.Password==portfolio.Password){
          res.send('success');
        }else{
          res.send('failed');
        }
      })
    },
    loadCreatePortfolio:function(req,res){

              Portfolio.find(function(err, portfolios){

                  if(err)
                      res.send(err.message);
                  else
                      res.render('CreatePortfolio', {portfolios});
              })
    },
    getAllPorfolios:function(req, res){
        Portfolio.find().skip(10-1).limit(10).populate({path:'projects',options:{sort:{'created_at':1}}}).exec(function(err,portfolios){

            if(err)
                res.send(err.message);
            else
                res.render('AllPortfolios', {portfolio});
        })
    },

    registerAccount:function(req, res){

        Portfolio.find(function(err, portfolios){

            if(err)
                res.send(err.message);
            else
                res.render('Homepage', {portfolios});
        })
    },

    createPortfolio:function(req, res){
        Portfolio.update({_id:req.session.user._id},{$set:{
          name:req.body.Name,
          portfoliopicture : req.files[0].filename
        }} ).exec(function(){
          res.redirect('/viewProject');
        })

    }
}

module.exports = portfolioController;
