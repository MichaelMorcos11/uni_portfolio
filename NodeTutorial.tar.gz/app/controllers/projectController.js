let Project = require('../models/Project');
let Portfolio = require('../models/Portfolio')

let projectController = {

    getAllProjects:function(req, res){

        Portfolio.find({_id:req.body.id}).populate('projects').exec(function(err, projects){

            if(err)
                res.send(err.message);
            else
                res.render('MyProjects', {projects});
        })
    },
    getAllPorfolios:function(req, res){

        Portfolio.find(function(err, portfolios){

            if(err)
                res.send(err.message);
            else
                res.render('Homepage', {portfolios});
        })
    },

    registerAccount:function(req, res){

        Project.find(function(err, projects){

            if(err)
                res.send(err.message);
            else
                res.render('Homepage', {projects});
        })
    },
viewsscreenshot:function(req,res){
  Project.findOne({_id:req.body.thiswork },function(err,project){
    if(err)
    res.send(err.message);

    else
    res.render('ViewProject',{project: project});
  })
},
    createProject:function(req, res){
        let project = new Project(req.body);

        project.save(function(err, project){
            if(err){
                res.send(err.message)
                console.log(err);
            }
            else{

                console.log(project);
                
                res.redirect('/');
            }
        })
    }
}

module.exports = projectController;
